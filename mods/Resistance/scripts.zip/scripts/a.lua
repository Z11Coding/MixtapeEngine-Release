function onCreatePost()
    addHaxeLibrary('HealthIcon')
    addHaxeLibrary('FlxMath', 'flixel.math')
    addHaxeLibrary("CoolUtil")
    runHaxeCode([[
		game.initLuaShader('pixel');

		shader0 = game.createRuntimeShader('pixel');
		shader0.setFloat('pxSize',0.1);

		game.camGame.setFilters([new ShaderFilter(shader0)]);
		game.camHUD.setFilters([new ShaderFilter(shader0)]);
	]])
end

function onStepHit()
    if curStep >= 1775 and curStep <= 1783 then
        doPixel = true
    else
        doPixel = false
    end
    if curStep >= 2800 and curStep <= 2808 then
        unDoPixel = true
    else
        unDoPixel = false
    end
    if curStep == 1263 then
        doTweenX("z11", "gf", 400, 1, "sineOut")
    end
    if curStep == 1535 then
        doTweenY("z11", "gf", -2000, 12, "sineOut")
        doTweenAngle("z11a", "gf", 360, 6, "sineOut")
        doTweenAlpha("z11al", "gf", 0, 2, "sineOut")
    end
end


function onUpdatePost()
    if doPixel then
        runHaxeCode('shader0.setFloat(\'pxSize\', shader0.getFloat(\'pxSize\') + 0.1);')
    end
    if unDoPixel then
        runHaxeCode('shader0.setFloat(\'pxSize\', shader0.getFloat(\'pxSize\') - 0.1);')
    end
end

